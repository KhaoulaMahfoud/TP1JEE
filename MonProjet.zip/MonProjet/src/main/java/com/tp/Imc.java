package com.tp;

public class Imc {
private double taille;
private double poids;
public Imc(double taille, double poids) {
	this.taille=taille;
	this.poids=poids;
}
double calcul() {
	return poids/(taille*taille);
}
public double getTaille() {
    return taille;
}

public double getPoids() {
    return poids;
}
}