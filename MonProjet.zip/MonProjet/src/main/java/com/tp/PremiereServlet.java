package com.tp;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/PremiereServlet")
public class PremiereServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public PremiereServlet() {
        super();
    }
// *************************EXERCICE 1 QUESTION 3***********************
// protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {   
//		response.getWriter().append("Served at: ").append(request.getContextPath());     response.setContentType("text/html"); 
//		        PrintWriter out = response.getWriter();
//		        out.println("<!DOCTYPE html>");
//		        out.println("<html>");
//		        out.println("<head>");
//		        out.println("<title>Example</title>");
//		        out.println("</head>");
//		        out.println("<body>");
//		        out.println("<p> C'est ma première servlet !</p>");
//		        out.println("</body>");
//		        out.println("</html>");
//		    }
		
 // *************************EXERCICE 1 QUESTION 5***********************
//@WebServlet("/bonjour")
//public class PremiereServlet extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//
//    public PremiereServlet() {
//        super();
//    }
// protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {   
// 		response.getWriter().append("Served at: ").append(request.getContextPath());     response.setContentType("text/html"); 
// 		        PrintWriter out = response.getWriter();
// 		        out.println("<!DOCTYPE html>");
// 		        out.println("<html>");
// 		        out.println("<head>");
// 		        out.println("<title>Example</title>");
// 		        out.println("</head>");
// 		        out.println("<body>");
// 		        out.println("<p> C'est ma première servlet !</p>");
// 		        out.println("</body>");
// 		        out.println("</html>");
// 		    }
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
