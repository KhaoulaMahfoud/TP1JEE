package com.tp;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

    @WebServlet("/resultat")
    public class resultat extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public resultat() {
        super();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Double resultatIMC = (Double) session.getAttribute("resultatIMC");
        if (resultatIMC != null) {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h1>Résultat du calcul de l'IMC :</h1>");
            out.println("<p>Votre IMC est : " + resultatIMC + "</p>");
            out.println("</body></html>");
        } else {
            response.getWriter().println("Aucun résultat trouvé.");
        }
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		doGet(request, response);
	}

}
