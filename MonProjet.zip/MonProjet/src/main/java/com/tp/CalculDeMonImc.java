package com.tp;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
@WebServlet("/CalculDeMonImc")
public class CalculDeMonImc extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public CalculDeMonImc() {
        super(); }
    //*****************Exercice 2 Question 1********************************
//protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("Served at:\n").append(request.getContextPath());
//	        PrintWriter out = response.getWriter();
//	        String poidsurl =request.getParameter("poids");
//	        String tailleurl =request.getParameter("taille");
//	        try {
//	        if (poidsurl==null || tailleurl==null) {
//	        throw new IllegalArgumentException("veuillez entrer les valeurs poids et taille");   }
//	        double poids =Double.parseDouble(poidsurl);
//	        double taille =Double.parseDouble(tailleurl);
//	        if(taille==0) {
//	        throw new ArithmeticException ("veuillez entrez une taille non nulle");
//	        }
//	        double imc =poids / (taille*taille);
//	        out.println("\n");
//	        out.println("votre imc est : "+ imc);
//	        }
//	        catch (IllegalArgumentException e) {
//	        	out.println(e.getMessage());}
//	        catch (ArithmeticException e) {
//	        	out.println(e.getMessage());}
//	}
//    
  //*****************Exercice 2 Question 2********************************
//  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//	response.getWriter().append("Served at:\n").append(request.getContextPath());
//        PrintWriter out = response.getWriter();
//        String poidsurl =request.getParameter("poids");
//        String tailleurl =request.getParameter("taille");
//        try {
//        if (poidsurl==null || tailleurl==null) {
//        throw new IllegalArgumentException("veuillez entrer les valeurs poids et taille");   }
//        double poids =Double.parseDouble(poidsurl);
//        double taille =Double.parseDouble(tailleurl);
//        if(taille==0) {
//        throw new ArithmeticException ("veuillez entrez une taille non nulle");
//        }
//        double imc =poids / (taille*taille);
//        out.println("\n");
//        out.println("votre imc est : "+ imc);
//        }
//        catch (IllegalArgumentException e) {
//        	out.println(e.getMessage());}
//        catch (ArithmeticException e) {
//        	out.println(e.getMessage());}
//}

    
//*****************Exercice 2 Question 4********************************
//	     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		 PrintWriter out=response.getWriter();
//	     double poids =Double.parseDouble(request.getParameter("poids"));
//	     double taille=Double.parseDouble(request.getParameter("taille"));
//	     double imc =poids / (taille*taille);
//	     out.println("\n");
//	     out.println("votre imc est : "+ imc);
//	}
    
  //*****************Exercice 3 Question 5********************************
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out=response.getWriter();
		 double poids =Double.parseDouble(request.getParameter("poids"));
		 double taille =Double.parseDouble(request.getParameter("taille"));
		 Imc imc =new Imc (taille,poids);
		 double resultat =imc.calcul();
		 
		 HttpSession session = request.getSession();
		 session.setAttribute("resultatIMC", resultat);
		 response.sendRedirect("resultat");
		
}
}